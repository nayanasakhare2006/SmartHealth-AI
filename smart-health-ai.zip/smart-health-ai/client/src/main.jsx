import React from 'react';
import { createRoot } from 'react-dom/client';
import { CssBaseline, ThemeProvider, createTheme } from '@mui/material';
import App from './App.jsx';
import './styles.css';
const theme=createTheme({palette:{primary:{main:'#087f8c'},secondary:{main:'#ef8354'},background:{default:'#f4f7fa',paper:'#ffffff'},success:{main:'#16856b'},warning:{main:'#d98b12'},error:{main:'#d94f4f'}},typography:{fontFamily:'Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',button:{textTransform:'none',fontWeight:650}},shape:{borderRadius:14},components:{MuiCard:{styleOverrides:{root:{border:'1px solid #e8edf2',boxShadow:'0 4px 20px rgba(27,48,69,.035)'}}},MuiButton:{defaultProps:{disableElevation:true}}}});
createRoot(document.getElementById('root')).render(<React.StrictMode><ThemeProvider theme={theme}><CssBaseline/><App/></ThemeProvider></React.StrictMode>);
