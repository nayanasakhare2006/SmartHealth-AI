import 'dotenv/config';
import mongoose from 'mongoose';
import HealthCenter from './models/HealthCenter.js';
import Inventory from './models/Inventory.js';
import Activity from './models/Activity.js';
await mongoose.connect(process.env.MONGODB_URI||'mongodb://127.0.0.1:27017/smart_health');
await Promise.all([HealthCenter.deleteMany({}),Inventory.deleteMany({}),Activity.deleteMany({})]);
const centers=await HealthCenter.create([
 {name:'Berasia Primary Health Centre',code:'PHC-001',type:'PHC',district:'Bhopal',bedsTotal:12,bedsAvailable:5,doctorsExpected:4,doctorsPresent:3,patientsToday:86,testAvailability:['CBC','Blood Sugar','Malaria']},
 {name:'Kolar Community Health Centre',code:'CHC-002',type:'CHC',district:'Bhopal',bedsTotal:40,bedsAvailable:13,doctorsExpected:8,doctorsPresent:8,patientsToday:142,testAvailability:['CBC','Blood Sugar','X-Ray','ECG']},
 {name:'Phanda Primary Health Centre',code:'PHC-003',type:'PHC',district:'Bhopal',bedsTotal:10,bedsAvailable:0,doctorsExpected:3,doctorsPresent:2,patientsToday:64,testAvailability:['Blood Sugar']},
 {name:'Gandhi Nagar Community Health Centre',code:'CHC-004',type:'CHC',district:'Bhopal',bedsTotal:35,bedsAvailable:9,doctorsExpected:7,doctorsPresent:5,patientsToday:118,testAvailability:['CBC','X-Ray','Malaria']}
]);
const items=[];
for(const [idx,c] of centers.entries()) { items.push({center:c._id,medicine:'Paracetamol 500mg',batch:`PCM-${idx+1}`,quantity:[8,120,0,14][idx],minimumStock:20,unit:'strips'}); items.push({center:c._id,medicine:'ORS Sachets',batch:`ORS-${idx+1}`,quantity:[70,160,12,55][idx],minimumStock:25,unit:'sachets'}); items.push({center:c._id,medicine:'Amoxicillin 250mg',batch:`AMX-${idx+1}`,quantity:[18,90,9,42][idx],minimumStock:20,unit:'strips'}); }
await Inventory.create(items);
await Activity.create(centers.flatMap((c,i)=>[{center:c._id,type:'patient',label:'Patients registered today',value:c.patientsToday,date:new Date()},{center:c._id,type:'attendance',label:'Doctors present',value:c.doctorsPresent,date:new Date()},{center:c._id,type:'test',label:'Tests currently available',value:c.testAvailability.length,date:new Date()}]));
console.log('Demo data created.'); await mongoose.disconnect();
