import mongoose from 'mongoose';
const inventorySchema = new mongoose.Schema({
  center: { type: mongoose.Schema.Types.ObjectId, ref: 'HealthCenter', required: true },
  medicine: { type: String, required: true, trim: true }, batch: { type: String, default: 'N/A' },
  quantity: { type: Number, min: 0, default: 0 }, minimumStock: { type: Number, min: 0, default: 20 },
  unit: { type: String, default: 'strips' }, expiryDate: { type: Date }
}, { timestamps: true });
inventorySchema.virtual('isLowStock').get(function(){ return this.quantity <= this.minimumStock; });
inventorySchema.set('toJSON', { virtuals: true });
export default mongoose.model('Inventory', inventorySchema);
