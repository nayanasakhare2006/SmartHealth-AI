import mongoose from 'mongoose';
const healthCenterSchema = new mongoose.Schema({
  name: { type: String, required: true }, code: { type: String, required: true, unique: true },
  type: { type: String, enum: ['PHC', 'CHC'], default: 'PHC' }, district: { type: String, default: 'Bhopal' },
  bedsTotal: { type: Number, default: 10 }, bedsAvailable: { type: Number, default: 5 },
  doctorsExpected: { type: Number, default: 3 }, doctorsPresent: { type: Number, default: 2 },
  testAvailability: { type: [String], default: ['CBC', 'Blood Sugar'] }, patientsToday: { type: Number, default: 0 },
  status: { type: String, enum: ['Operational', 'Needs Attention', 'Critical'], default: 'Operational' }
}, { timestamps: true });
export default mongoose.model('HealthCenter', healthCenterSchema);
