import mongoose from 'mongoose';
const activitySchema = new mongoose.Schema({
  center: { type: mongoose.Schema.Types.ObjectId, ref: 'HealthCenter', required: true },
  type: { type: String, enum: ['patient', 'attendance', 'test'], required: true },
  label: { type: String, required: true }, value: { type: Number, default: 1 },
  date: { type: Date, default: Date.now }, notes: { type: String, default: '' }
}, { timestamps: true });
export default mongoose.model('Activity', activitySchema);
