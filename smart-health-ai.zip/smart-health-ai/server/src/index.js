import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import api from './routes/api.js';
const app=express();
app.use(cors({origin:process.env.CLIENT_URL?.split(',') || 'http://localhost:5173'}));
app.use(express.json({limit:'1mb'}));
app.use('/api',api);
app.use((err,_req,res,_next)=>{ console.error(err); if(err.code===11000)return res.status(409).json({message:'That code already exists.'}); if(err.name==='ValidationError')return res.status(400).json({message:err.message}); if(err.name==='CastError')return res.status(400).json({message:'Invalid record ID.'}); res.status(500).json({message:'Server error. Check API logs.'}); });
const port=process.env.PORT||5000;
try { await mongoose.connect(process.env.MONGODB_URI||'mongodb://127.0.0.1:27017/smart_health'); console.log('MongoDB connected'); app.listen(port,()=>console.log(`Smart Health API running on http://localhost:${port}`)); }
catch(err){ console.error('MongoDB connection failed:',err.message); console.error('Start MongoDB or set MONGODB_URI in server/.env'); process.exit(1); }
