# Smart Health AI — Hackathon MVP

A responsive district health-centre operations dashboard for PHCs/CHCs. It includes MongoDB persistence, inventory CRUD, stock-out/low-stock alerts, centre status, bed availability, staff attendance visibility, patient footfall, diagnostic test listings, and explainable rule-based redistribution/reorder suggestions.

> **Scope note:** this is a working hackathon prototype, not a clinically validated AI system. Forecasts/recommendations are simple rules and must be reviewed by health administrators. No real patient-identifying data is included.

## Stack
- Frontend: React + Vite, Material UI, Recharts, Axios
- Backend: Node.js + Express
- Database: MongoDB + Mongoose

## Requirements
- Node.js 20+ recommended
- MongoDB local service OR MongoDB Atlas connection string

## Run it (Bash)
From the `smart-health-ai` directory:

```bash
# 1. Configure backend environment
cp server/.env.example server/.env
# If using MongoDB Atlas, edit server/.env and set MONGODB_URI to your connection string.

# 2. Install root, backend and frontend dependencies
npm install
npm run install:all

# 3. Start MongoDB locally in another terminal if using local MongoDB
# e.g. on Linux: sudo systemctl start mongod

# 4. Add demo data (run once; this clears existing demo collections!)
npm run seed

# 5. Start API and frontend together
npm run dev
```

Open **http://localhost:5173**. Backend health check: **http://localhost:5000/api/health**.

### Run separately
```bash
npm run dev --prefix server
npm run dev --prefix client
```

### Environment variables
`server/.env`:
```env
PORT=5000
MONGODB_URI=mongodb://127.0.0.1:27017/smart_health
CLIENT_URL=http://localhost:5173
```
For a hosted frontend, set `VITE_API_URL` to the deployed backend URL plus `/api` before building. Configure CORS `CLIENT_URL` to your frontend origin.

## Main API routes
| Method | Route | Purpose |
|---|---|---|
| GET | `/api/health` | API health check |
| GET/POST | `/api/centers` | List/create health centres |
| PATCH | `/api/centers/:id` | Update a centre |
| GET/POST | `/api/inventory` | List/create medicine stock records |
| PATCH/DELETE | `/api/inventory/:id` | Update/delete a stock record |
| GET/POST | `/api/activity` | List/create patient, attendance, or test activity |
| GET | `/api/dashboard` | Dashboard statistics, alerts and recommendations |

## Features
- Overview metrics, patient footfall chart, bed availability bars, centre status and priority alerts.
- Inventory search/filter by centre; add, edit, delete stock records.
- Alerts for stock at/below minimum, stock-outs, staff gaps and no available beds.
- Rule-based suggestions to transfer surplus of the same medicine or reorder it if no surplus is found.
- English/Hindi UI toggle and responsive desktop/mobile layout.

## Important production gaps
Before real-world deployment, add authentication/role-based access, audit logs, request validation/rate limits, HTTPS, backups, monitoring, data retention controls, proper district/centre permissions, and security review. Do not enter real patient data into this demo. Actual forecasting needs reliable historical data and validation; current patient values are seeded demo values.
